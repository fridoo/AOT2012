package de.dailab.aot.sose2012;

import de.dailab.jiactng.agentcore.SimpleAgentNode;

public class Lesson1Starter {

	public static void main(String[] args) {
		SimpleAgentNode.main(new String[] { "classpath:configuration.xml" });
	}

}
